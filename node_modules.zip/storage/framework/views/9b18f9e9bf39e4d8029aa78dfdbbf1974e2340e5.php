<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-2">
        <div class="row">

            <center class="mb-5">
                <h1 class="text-5xl text-white font-bold">Service Providers</h1>
            </center>

            <?php $__currentLoopData = $serviceProviders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceProvider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 bg-gray-600 bg-opacity-20 rounded-2xl shadow-sm shadow-gray-300 backdrop-blur-sm mb-8 hover:bg-opacity-50 transition duration-500 ease-in-out">
                    <div class="flex gap-8 justify-start">
                        <div class="img relative w-1/4">
                            <img src="<?php echo e(asset('storage/profile_photos/' . $serviceProvider->profile_image)); ?>" class="card-img-top rounded-l-[12px] m-1 w-60 h-60 object-cover" alt="...">
                            <span class="absolute left-[4px] text-lg top-[2px] text-gray-400">
                                         <?php if($serviceProvider->isVerified): ?>
                                    <i class="fa-solid fa-lg fa-check-circle text-green-400"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-lg fa-times-circle text-red-600"></i>
                                <?php endif; ?>
                                    </span>
                        </div>
                        <div class="flex w-3/4 flex-col justify-between text-white">
                            <div class="my-4">
                                <h5 class="text-3xl w-fit">
                                    <?php echo e($serviceProvider->company_name); ?>

                                </h5>
                                <p class="text-sm">
                                    <?php echo e($serviceProvider->description); ?>

                                </p>

                                
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('service-provider-rating', ['serviceProvider' => $serviceProvider])->html();
} elseif ($_instance->childHasBeenRendered(''.e($serviceProvider->company_name).'')) {
    $componentId = $_instance->getRenderedChildComponentId(''.e($serviceProvider->company_name).'');
    $componentTag = $_instance->getRenderedChildComponentTagName(''.e($serviceProvider->company_name).'');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(''.e($serviceProvider->company_name).'');
} else {
    $response = \Livewire\Livewire::mount('service-provider-rating', ['serviceProvider' => $serviceProvider]);
    $html = $response->html();
    $_instance->logRenderedChild(''.e($serviceProvider->company_name).'', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                <Livewire:user-reviews-test />

                            </div>
                            <p class="flex items-center justify-between my-2 gap-4">
                                <span class="flex items-center my-2 gap-4">
                                    <span class="date flex gap-2">
                                    <i class="fa-solid fa-envelope-circle-check"></i>
                                    <span class="text-xs">
                                        <?php echo e($serviceProvider->email); ?>

                                    </span>
                                </span>
                                <span class="loc flex gap-2">
                                    <i class="fa-solid fa-phone-flip"></i>
                                    <span class="text-xs">
                                        <?php echo e($serviceProvider->contact_number); ?>

                                    </span>
                                </span>
                                <span class="verified <?php echo e($serviceProvider->isVerified ? 'text-green-400' : 'text-red-600'); ?> text-xs flex gap-2">
                                    <?php if($serviceProvider->isVerified): ?>
                                        VERIFIED
                                    <?php else: ?>
                                        NOT VERIFIED
                                    <?php endif; ?>
                                </span>
                                </span>

                                <a href="<?php echo e(route('service-providers.show', $serviceProvider->id)); ?>" class="mx-2">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'ring-0 shadow-gray-300 shadow-sm btn-sm hover:bg-orange-600 hover:text-white transition-all duration-500 ease-in-out']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ring-0 shadow-gray-300 shadow-sm btn-sm hover:bg-orange-600 hover:text-white transition-all duration-500 ease-in-out']); ?>
                                        View
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </a>
                            </p>
                        </div>

                        <div class=" absolute right-2 text-xs top-2 text-gray-400">
                            OWNER: <?php echo e($serviceProvider->user->name ?? ''); ?>

                        </div>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <!-- Pagination -->
            <div class="pagination mt-5">
                <?php echo e($serviceProviders->links()); ?>

            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php /**PATH D:\Apps\servicebay\resources\views/service-providers/index.blade.php ENDPATH**/ ?>