<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container text-white flex gap-4">
        <div class="left w-1/3 border-r-2 border-r-gray-200">
            <img src="<?php echo e(asset('storage/profile_photos/' . $serviceProvider->profile_image)); ?>" class="card-img-top rounded-[12px] m-1 w-40 h-40 object-cover" alt="...">
        </div>
        <div class="right w-2/3">
            <div class="data">
                <h1 class="text-3xl w-fit">
                    <?php echo e($serviceProvider->company_name); ?>

                </h1>
                <livewire:service-provider-rating :serviceProvider="$serviceProvider" key="<?php echo e($serviceProvider->id); ?>" />

                <div class="flex flex-col gap-4 justify-between text-white">
                    <div class="desc my-4">
                        <p class="text-xs">
                            <?php echo e($serviceProvider->description); ?>

                        </p>
                    </div>

                    <div class="info my-3 flex gap-4 items-center">
                        <div class="email flex gap-2 items-center">
                            <i class="fa-solid fa-envelope"></i>
                            <span class="text-xs">
                            <?php echo e($serviceProvider->email); ?>

                        </span>
                        </div>

                        <div class="contact flex gap-2 items-center">
                            <i class="fa-solid fa-phone-flip"></i>
                            <span class="text-xs">
                            <?php echo e($serviceProvider->contact_number); ?>

                        </span>
                        </div>

                        <div class="verified <?php echo e($serviceProvider->isVerified ? 'text-green-400' : 'text-red-600'); ?> text-xs flex gap-2">
                            <?php if($serviceProvider->isVerified): ?>
                                VERIFIED
                            <?php else: ?>
                                NOT VERIFIED
                            <?php endif; ?>
                        </div>

                    </div>

                    <div class="3recentReviews">

                        <h1 class="text-2xl">
                            Recent Reviews
                        </h1>

                        <?php ($ratings = $serviceProvider->serviceReviewRatings->sortByDesc('created_at')->take(3)); ?>
                        <div class="reviews flex justify-between">
                            <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="review shadow shadow-gray-300 m-1 p-2 rounded w-1/3">
                                    <div class="rating">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= $review->rating): ?>
                                                <i class="fas fa-star text-warning"></i>
                                            <?php else: ?>
                                                <i class="far fa-star text-warning"></i>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </div>
                                    <div class="comment text-xs">
                                        <?php echo e($review->comments); ?>

                                    </div>
                                    <div class="date mt-2 text-[8px]">
                                        <?php echo e($review->created_at->diffForHumans()); ?>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\Apps\servicebay\resources\views/service-providers/show.blade.php ENDPATH**/ ?>