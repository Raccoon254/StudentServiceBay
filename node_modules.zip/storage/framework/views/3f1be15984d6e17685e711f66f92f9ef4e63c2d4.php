<!--Check if there are any messages within the session-->
<?php if(session('success')): ?>
    <div class="alert rounded-[0px] mt-3 alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('info')): ?>
    <div class="alert rounded-[0px] mt-3 alert-info">
        <?php echo e(session('info')); ?>

    </div>
<?php endif; ?>

<?php if(session('warning')): ?>
    <div class="alert rounded-[0px] mt-3 alert-warning">
        <?php echo e(session('warning')); ?>

    </div>
<?php endif; ?>

<?php if(session('message')): ?>
    <div class="alert rounded-[0px] mt-3 alert-primary">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert rounded-[0px] text-white border-0 mt-3 bg-red-500 alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert rounded-[0px] mt-3 bg-red-500 alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH D:\Apps\servicebay\resources\views/session/alerts.blade.php ENDPATH**/ ?>