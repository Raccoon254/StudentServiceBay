<div class="drawer w-0 md:w-64 md:drawer-open">
    <input id="my-drawer" type="checkbox" class="drawer-toggle" />
    <div class="">

    </div>
    <div class="z-40 drawer-side">
        <label for="my-drawer" class="drawer-overlay"></label>

        <div class="menu overflow-clip p-4 w-64 h-full backdrop-blur-sm bg-gray-500 bg-opacity-30 border-r border-gray-200 text-base-content gap-4 flex flex-col justify-center items-center">
            <!-- App Logo -->
            <div class="flex items-center w-full justify-center gap-4">
                <a href="<?php echo e(route('dashboard')); ?>">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'block w-[60px] fill-current text-gray-800']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block w-[60px] fill-current text-gray-800']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </a>
            </div>

            <!-- Sidebar content here -->
            <a href="<?php echo e(route('dashboard')); ?>" class="side <?php echo e(Route::is('dashboard') ? 'active' : ''); ?>">
                <i class="fa-solid fa-home-lg"></i>
                <div class="">
                    Dashboard
                </div>
            </a>

            <a href="<?php echo e(route('profile.edit')); ?>" class="side <?php echo e(Route::is('profile.edit') ? 'active' : ''); ?>">
                <i class="fa-regular fa-circle-user"></i>
                <div class="">
                    Profile
                </div>
            </a>

            <a href="<?php echo e(route('service.providers')); ?>" class="side <?php echo e(Route::is(['service.providers','service-providers.show']) ? 'active' : ''); ?>">
                <i class="fa-solid fa-gears"></i>
                <div class="">
                    Service Providers
                </div>
            </a>

            <a href="<?php echo e(route('reviews.index')); ?>" class="side <?php echo e(Route::is(['reviews.index','reviews.show']) ? 'active' : ''); ?>">
                <i class="fa-solid fa-star-half-stroke"></i>
                <div class="">
                    Reviews
                </div>
            </a>

            <a class="side" href="" >
                <i class="fa-solid fa-bell"></i>
                <div class="">
                    Notifications
                </div>
            </a>

            <a href="<?php echo e(route('scam.index')); ?>" class="side <?php echo e(Route::is(['scam.index','scam.show','scam.create']) ? 'active' : ''); ?>">
                <i class="fa-solid text-red-600 fa-triangle-exclamation"></i>
                <div class="">
                    Scam Alerts
                </div>
            </a>

            <!-- Logout -->
            <form method="POST" class="side" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <i class="fa-solid fa-sign-out"></i>
                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();">
                    <div class="">
                        <?php echo e(__('Log Out')); ?>

                    </div>
                </a>
            </form>


        </div>
    </div>
</div>
<?php /**PATH D:\Apps\servicebay\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>