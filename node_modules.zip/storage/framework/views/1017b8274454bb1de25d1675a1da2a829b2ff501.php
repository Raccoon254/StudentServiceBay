<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'btn ring ring-white btn-secondary font-semibold text-xs min-w-[100px] text-white uppercase tracking-widest focus:ring-offset-2 transition ease-in-out duration-150'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH D:\Apps\servicebay\resources\views/components/secondary-button.blade.php ENDPATH**/ ?>