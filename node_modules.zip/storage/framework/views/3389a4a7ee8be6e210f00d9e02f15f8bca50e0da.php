<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="h-5/6 text-white w-full flex flex-col items-center justify-center">

        <div class="text-5xl font-semibold">
            <h1 class="text-center"> THE STUDENT SERVICE BAY</h1>
        </div>

        <div class="flex gap-4">
            Welcome to the student bay, a place where you can find all notices and updates for local companies, businesses and services.
        </div>

        <?php

        $topRatedCompanies = App\Models\ServiceProvider::with('serviceReviewRatings')
            ->withCount(['serviceReviewRatings as average_rating' => function ($query) {
                $query->select(DB::raw('coalesce(avg(rating),0)'));
            }])
            ->orderByDesc('average_rating')
            ->take(3)
            ->get();

        ?>

        <div class="top mt-8">
            <h2 class="text-3xl text-center font-semibold">Top Rated Companies</h2>
            <div class="flex mt-4 gap-4">

                <?php $__currentLoopData = $topRatedCompanies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="shadow shadow-gray-50 overflow-clip p-1 w-[200px] rounded-md">
                        <div class="img">
                            <img src="<?php echo e(asset('storage/profile_photos/' . $company->profile_image)); ?>" alt="<?php echo e($company->company_name); ?>" class="rounded-md w-[200px] h-[150px] object-cover" />
                        </div>
                        <div class="more-data flex flex-col gap-2 p-1 bg-gradient-to-b from-gray-900 to-gray-800 hover:from-gray-800 hover:to-gray-900 rounded-md hover:shadow-lg">
                            <?php ($companyNameShort = strlen($company->company_name) > 15 ? substr($company->company_name, 0, 15) . '...' : $company->company_name); ?>

                            <h3 class="text-xl"><?php echo e($companyNameShort); ?></h3>
                            <p class="text-xs">Average Rating: <?php echo e(number_format($company->average_rating, 1)); ?></p>
                            <div class="stars">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <?php if($i <= $company->average_rating): ?>
                                        <i class="fas fa-star text-warning"></i>
                                    <?php else: ?>
                                        <i class="far fa-star text-warning"></i>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\Apps\servicebay\resources\views/dashboard.blade.php ENDPATH**/ ?>