<?php return array (
  'service-provider-rating' => 'App\\Http\\Livewire\\ServiceProviderRating',
  'user-reviews' => 'App\\Http\\Livewire\\UserReviews',
);